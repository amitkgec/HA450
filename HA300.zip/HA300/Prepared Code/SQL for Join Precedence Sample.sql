

-- Sample join query where MJ_CUSTOMERS and MJ_COUNTRIES are joined first
-- Equivalent to an 'Outside in' multi-join node with HA300::MJ_SALES as the central table in a graphical calculation view

SELECT A.ORDER_ID, A.CUSTOMER, A.AMOUNT, C.REGION
FROM "HA300::MJ_SALES" A
LEFT JOIN ("HA300::MJ_CUSTOMERS" B
           INNER JOIN "HA300::MJ_COUNTRIES" C
           ON B.COUNTRY=C.COUNTRY_ID)
ON A.CUSTOMER=B.CUSTOMER_ID;

-- Sample join query where MJ_SALES and MJ_CUSTOMERS are joined first
-- Equivalent to an 'Inside out' multi-join node with HA300::MJ_SALES as the central table in a graphical calculation view

SELECT A.ORDER_ID, A.CUSTOMER, A.AMOUNT, C.REGION
FROM ("HA300::MJ_SALES" A
      LEFT JOIN "HA300::MJ_CUSTOMERS" B
      ON A.CUSTOMER=B.CUSTOMER_ID)
INNER JOIN "HA300::MJ_COUNTRIES" C
ON B.COUNTRY=C.COUNTRY_ID;