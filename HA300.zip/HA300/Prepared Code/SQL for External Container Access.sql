-- EXERCISE: PREPARE YOUR SAP HANA SYSTEM

-- Preparation:
-- First replace ## everywhere in this script with your group number

-- 1. Check the name of your container access role, to be used in the query #2 below.
SELECT * FROM ROLES WHERE ROLE_NAME LIKE '%HA300_##%access_role';

-- 2. Grant the relevant roles to your user STUDENT## who will query Calculation Views from external tools, outside of the Web IDE.
GRANT "HA300_##_HDI_HDB_1::access_role" to TRAINING_ROLE_##;