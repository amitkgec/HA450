-- EXERCISE: CREATE AND ASSIGN AN ANALYTIC PRIVILEGE

-- Preparation:
-- First replace ## everywhere in this script with your group number

-- 1. Assign DATA_VIEWER role to your user
GRANT "HA300_##_HDI_HDB_1"."HA300::DATA_VIEWER" TO TRAINING_ROLE_##;

-- 2. Assign DATA_VIEWER2 role to your user and preview the calculation view
GRANT "HA300_##_HDI_HDB_1"."HA300::DATA_VIEWER2" TO TRAINING_ROLE_##;
SELECT DISTINCT COUNTRY, CATEGORY FROM "HA300_##_HDI_HDB_1"."HA300::CVCS_PO3_AP";

-- 3. Revoke role DATA_VIEWER2 and assign role DATA_VIEWER3 to your user, and preview the calculation view

REVOKE "HA300_##_HDI_HDB_1"."HA300::DATA_VIEWER2" FROM TRAINING_ROLE_##;
GRANT "HA300_##_HDI_HDB_1"."HA300::DATA_VIEWER3" TO TRAINING_ROLE_##;
SELECT DISTINCT COUNTRY, CATEGORY FROM "HA300_##_HDI_HDB_1"."HA300::CVCS_PO3_AP";

-- 4. Revoke role DATA_VIEWER3 from your user (optional) 
REVOKE "HA300_##_HDI_HDB_1"."HA300::DATA_VIEWER3" FROM TRAINING_ROLE_##;