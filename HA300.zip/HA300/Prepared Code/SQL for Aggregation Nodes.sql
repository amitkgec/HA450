-- EXERCISE: CONTROL THE BEHAVIOR OF THE AGGREGATION NODE

-- QUERY 1.a: Visualize the source data (table TRAINING.ORDERS, which is referenced by a synonym "HA300::ORDERS")

SELECT * FROM "HA300::ORDERS";


-- QUERY 3.a: Query the column view data with the ORDER_ID column

SELECT
	 "ORDER_ID",
	 "PRODUCT",
	 sum("QUANTITY") AS "QUANTITY",
	 sum("UNIT_PRICE") AS "UNIT_PRICE",
	 sum("TOTAL_PRICE") AS "TOTAL_PRICE"
FROM "HA300::CVC_ORDERS_AGGREGATION"
GROUP BY "ORDER_ID",
         "PRODUCT";


-- QUERY 3.b: Query the column view data without the ORDER_ID column

SELECT
	 "PRODUCT",
	 sum("QUANTITY") AS "QUANTITY",
	 sum("UNIT_PRICE") AS "UNIT_PRICE",
	 sum("TOTAL_PRICE") AS "TOTAL_PRICE"
FROM "HA300::CVC_ORDERS_AGGREGATION"
GROUP BY "PRODUCT";


-- QUERY 4.a: Query the column view data group by PRODUCT and STORE

SELECT
	 "PRODUCT",
	 "STORE",
	 sum("QUANTITY") AS "QUANTITY",
	 sum("TOTAL_PRICE") AS "TOTAL_PRICE"
FROM "HA300::CVC_ORDERS_AGGREGATION"
GROUP BY "PRODUCT",
         "STORE";