-- EXERCISE: DEFINE COLUMN MASKING IN A CALCULATION VIEW

-- Preparation:
-- First replace ## everywhere in this script with your group number

-- #1: Visualize the CVD_EMPLOYEES calculation view
SELECT * FROM "HA300_##_HDI_HDB_1"."HA300::CVD_EMPLOYEES_WITH_MASK";

-- #2: Authorize STUDENT## (via the role) to view the actual data of MASKED columns
GRANT "HA300_##_HDI_HDB_1"."HA300::UNMASK_ALL" TO TRAINING_ROLE_##;